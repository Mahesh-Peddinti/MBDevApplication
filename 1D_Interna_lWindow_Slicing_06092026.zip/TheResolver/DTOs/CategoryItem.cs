using System.ComponentModel;
using Autodesk.Revit.DB;

namespace TheResolver.DTOs
{
    /// <summary>
    /// One checkable MEP category inside a model's category tree.
    /// </summary>
    public class CategoryItem : INotifyPropertyChanged
    {
        private bool _isSelected = true;

        public string Name { get; set; }

        public BuiltInCategory Category { get; set; }

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected == value)
                    return;

                _isSelected = value;

                OnPropertyChanged(nameof(IsSelected));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(
                this,
                new PropertyChangedEventArgs(propertyName));
        }
    }
}
