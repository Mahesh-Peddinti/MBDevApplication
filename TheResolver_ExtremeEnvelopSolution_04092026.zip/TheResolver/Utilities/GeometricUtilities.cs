﻿using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Electrical;
using System;
using System.Collections.Generic;
using System.Linq;
using TheResolver.BusinessLogics;
using TheResolver.DTOs;
using TheResolver.Services;

namespace TheResolver.Utilities
{
    public class GeometricUtilities
    {
        private const double MM = 1.0 / 304.8;
        private const double GeometryTolerance = 1e-9;

        public LocalSpatialIndex SpatialIndex { get; set; }

        public List<ClashInfoDTOs> FindClashes(List<CableTray> trays, List<Element> multiCategoryElements, RouteSettingDTOs settings)
        {
            List<ClashInfoDTOs> result = new List<ClashInfoDTOs>();
            Dictionary<string, BoundingBoxXYZ> trayBoxes = new Dictionary<string, BoundingBoxXYZ>();

            foreach (CableTray tray in trays)
            {
                if (!trayBoxes.ContainsKey(tray.UniqueId))
                    trayBoxes.Add(tray.UniqueId, tray.get_BoundingBox(null));
            }

            Dictionary<string, BoundingBoxXYZ> clashElementBoxes = new Dictionary<string, BoundingBoxXYZ>();
            foreach (Element e in multiCategoryElements)
            {
                try
                {
                    BoundingBoxXYZ bb = e.get_BoundingBox(null);
                    if (bb != null && !clashElementBoxes.ContainsKey(e.UniqueId))
                        clashElementBoxes.Add(e.UniqueId, bb);
                }
                catch { }
            }

            foreach (CableTray tray in trays)
            {
                if (!trayBoxes.TryGetValue(tray.UniqueId, out BoundingBoxXYZ trayBox) || trayBox == null)
                    continue;

                foreach (Element elem in multiCategoryElements)
                {
                    if (tray.UniqueId == elem.UniqueId) continue;
                    if (!clashElementBoxes.TryGetValue(elem.UniqueId, out BoundingBoxXYZ clashElementBox) || clashElementBox == null)
                        continue;

                    if (!BoxesIntersect(trayBox, clashElementBox, 1.0 * MM))
                        continue;

                    List<Solid> traySolids = GetSolids(tray);
                    List<Solid> elementSolids = GetSolids(elem);
                    Solid intersection = null;

                    foreach (Solid ts in traySolids)
                    {
                        foreach (Solid es in elementSolids)
                        {
                            try
                            {
                                Solid test = BooleanOperationsUtils.ExecuteBooleanOperation(ts, es, BooleanOperationsType.Intersect);
                                if (test != null && test.Volume > GeometryTolerance)
                                {
                                    intersection = test;
                                    break;
                                }
                            }
                            catch { }
                        }
                        if (intersection != null) break;
                    }

                    if (intersection != null)
                    {
                        result.Add(new ClashInfoDTOs
                        {
                            Tray = tray,
                            ClashElement = elem,
                            Intersection = intersection,
                            Name = tray.Id.ToString()
                        });
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Generates an N-point, free-angle detour path avoiding all local secondary obstacles.
        /// </summary>
        public bool TryBuildBypassRoutingPoints(ClashInfoDTOs clash, RouteSettingDTOs settings, out List<XYZ> points)
        {
            points = new List<XYZ>();
            if (clash?.Tray == null || clash.ClashElement == null || settings == null)
                return false;

            if (!(clash.Tray.Location is LocationCurve trayLocation) || !(trayLocation.Curve is Line trayLine))
                return false;

            XYZ start = trayLine.GetEndPoint(0);
            XYZ end = trayLine.GetEndPoint(1);
            XYZ trayDirection = (end - start).Normalize();
            double trayLength = start.DistanceTo(end);

            XYZ clashCentroid = null;
            try
            {
                clashCentroid = clash.Intersection?.ComputeCentroid();
            }
            catch { }

            // FALLBACK: If solid boolean failed across Revit Link, use BoundingBox overlap center
            if (clashCentroid == null)
            {
                BoundingBoxXYZ tBox = clash.Tray.get_BoundingBox(null);
                BoundingBoxXYZ cBox = clash.ClashElement.get_BoundingBox(null);
                if (tBox != null && cBox != null)
                {
                    clashCentroid = new XYZ(
                        (Math.Max(tBox.Min.X, cBox.Min.X) + Math.Min(tBox.Max.X, cBox.Max.X)) * 0.5,
                        (Math.Max(tBox.Min.Y, cBox.Min.Y) + Math.Min(tBox.Max.Y, cBox.Max.Y)) * 0.5,
                        (Math.Max(tBox.Min.Z, cBox.Min.Z) + Math.Min(tBox.Max.Z, cBox.Max.Z)) * 0.5
                    );
                }
            }

            if (clashCentroid == null)
            {
                Logger.Log("Could not determine clash center point.");
                return false;
            }

            double clashStation = (clashCentroid - start).DotProduct(trayDirection);
            double searchSpan = 3000.0 * MM; // 3m local ROI

            // Build local ROI box for spatial lookup
            XYZ roiCenter = start + trayDirection * clashStation;
            BoundingBoxXYZ roiBox = new BoundingBoxXYZ
            {
                Min = new XYZ(roiCenter.X - searchSpan, roiCenter.Y - searchSpan, roiCenter.Z - 2000 * MM),
                Max = new XYZ(roiCenter.X + searchSpan, roiCenter.Y + searchSpan, roiCenter.Z + 2000 * MM)
            };

            List<ObstacleBounds> localObstacles = SpatialIndex != null
                ? SpatialIndex.QueryRoi(roiBox)
                : new List<ObstacleBounds>();

            // If no spatial index provided, fallback to primary obstacle box
            if (localObstacles.Count == 0)
            {
                var pBox = clash.ClashElement.get_BoundingBox(null);
                if (pBox != null)
                    localObstacles.Add(new ObstacleBounds { Id = clash.ClashElement.UniqueId, Box = pBox, Element = clash.ClashElement });
            }

            // Tray dimensions
            double trayHeight = clash.Tray.get_Parameter(BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM)?.AsDouble() ?? (100 * MM);
            double requiredClearance = settings.MinimumClearance;

            // Project all obstacles touching the horizontal tray corridor into 2D (Station, Z) intervals
            double halfWidth = (clash.Tray.get_Parameter(BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM)?.AsDouble() ?? (300 * MM)) * 0.5 + settings.MinimumSideOffset;
            XYZ lateralDir = trayDirection.CrossProduct(XYZ.BasisZ).Normalize();

            List<RectInterval> obstacleProfiles = new List<RectInterval>();
            foreach (var obs in localObstacles)
            {
                if (obs.Id == clash.Tray.UniqueId) continue;

                // Check lateral overlap with tray corridor
                double latProjMin = double.MaxValue, latProjMax = double.MinValue;
                double stMin = double.MaxValue, stMax = double.MinValue;
                GetBoundingBoxCorners(obs.Box, corner =>
                {
                    double l = (corner - start).DotProduct(lateralDir);
                    latProjMin = Math.Min(latProjMin, l);
                    latProjMax = Math.Max(latProjMax, l);

                    double s = (corner - start).DotProduct(trayDirection);
                    stMin = Math.Min(stMin, s);
                    stMax = Math.Max(stMax, s);
                });

                if (latProjMax < -halfWidth || latProjMin > halfWidth)
                    continue; // Obstacle does not cross our vertical corridor plane

                // Only consider obstacles in the ROI station range
                if (stMax < clashStation - searchSpan || stMin > clashStation + searchSpan)
                    continue;

                obstacleProfiles.Add(new RectInterval
                {
                    StationMin = stMin - settings.MinimumSideOffset,
                    StationMax = stMax + settings.MinimumSideOffset,
                    ZMin = obs.Box.Min.Z - (requiredClearance + trayHeight),
                    ZMax = obs.Box.Max.Z + requiredClearance
                });
            }

            if (obstacleProfiles.Count == 0)
                return false;

            // Determine Detour Direction (+Z up or -Z down)
            bool routeUp = true;
            if (settings.PreferredDirection == RouteDirection.Down)
                routeUp = false;
            else if (settings.PreferredDirection == RouteDirection.Up)
                routeUp = true;
            else
            {
                // Auto direction: check which direction yields less elevation delta
                double highestObstacle = obstacleProfiles.Max(o => o.ZMax);
                double lowestObstacle = obstacleProfiles.Min(o => o.ZMin);
                double origZ = start.Z;

                routeUp = Math.Abs(highestObstacle - origZ) <= Math.Abs(origZ - lowestObstacle);
            }

            // Compute Target Plateau Elevation
            double targetElevation = routeUp
                ? obstacleProfiles.Max(o => o.ZMax)
                : obstacleProfiles.Min(o => o.ZMin);

            double angleRad = settings.BendAngle * Math.PI / 180.0;
            double deltaZ = Math.Abs(targetElevation - start.Z);
            double rampRun = deltaZ / Math.Tan(angleRad);
            double tangentLength = settings.BendRadius * Math.Tan(angleRad * 0.5);
            rampRun = Math.Max(rampRun, 60.0 * MM) + tangentLength;

            // Obstacle cluster boundaries
            double clusterStMin = obstacleProfiles.Min(o => o.StationMin);
            double clusterStMax = obstacleProfiles.Max(o => o.StationMax);

            // Establish multi-point stations
            double s1 = clusterStMin - rampRun;
            double s2 = clusterStMin;
            double s3 = clusterStMax;
            double s4 = clusterStMax + rampRun;

            // Feasibility boundary check
            double minMargin = 50.0 * MM;
            if (s1 < minMargin || s4 > (trayLength - minMargin))
                return false;

            XYZ dirZ = routeUp ? XYZ.BasisZ : -XYZ.BasisZ;
            XYZ p1 = start + trayDirection * s1;
            XYZ p2 = start + trayDirection * s2 + dirZ * deltaZ;
            XYZ p3 = start + trayDirection * s3 + dirZ * deltaZ;
            XYZ p4 = start + trayDirection * s4;

            points.Add(p1);
            points.Add(p2);
            points.Add(p3);
            points.Add(p4);

            BuildCleanRoutePoints cleaner = new BuildCleanRoutePoints();
            points = cleaner.CleanRoutePoints(points);

            return points.Count >= 4;
        }

        private static void GetBoundingBoxCorners(BoundingBoxXYZ box, Action<XYZ> action)
        {
            action(new XYZ(box.Min.X, box.Min.Y, box.Min.Z));
            action(new XYZ(box.Max.X, box.Min.Y, box.Min.Z));
            action(new XYZ(box.Min.X, box.Max.Y, box.Min.Z));
            action(new XYZ(box.Max.X, box.Max.Y, box.Min.Z));
            action(new XYZ(box.Min.X, box.Min.Y, box.Max.Z));
            action(new XYZ(box.Max.X, box.Min.Y, box.Max.Z));
            action(new XYZ(box.Min.X, box.Max.Y, box.Max.Z));
            action(new XYZ(box.Max.X, box.Max.Y, box.Max.Z));
        }

        private static bool BoxesIntersect(BoundingBoxXYZ a, BoundingBoxXYZ b, double tolerance)
        {
            return a.Min.X <= b.Max.X + tolerance && a.Max.X + tolerance >= b.Min.X &&
                   a.Min.Y <= b.Max.Y + tolerance && a.Max.Y + tolerance >= b.Min.Y &&
                   a.Min.Z <= b.Max.Z + tolerance && a.Max.Z + tolerance >= b.Min.Z;
        }

        private static List<Solid> GetSolids(Element element)
        {
            var solids = new List<Solid>();
            Options opt = new Options { DetailLevel = ViewDetailLevel.Fine, IncludeNonVisibleObjects = true, ComputeReferences = true };
            GeometryElement geo = element.get_Geometry(opt);
            if (geo == null) return solids;
            ExtractSolidsRecursive(geo, Transform.Identity, solids);
            return solids;
        }

        private static void ExtractSolidsRecursive(GeometryElement geo, Transform transform, List<Solid> solids)
        {
            foreach (GeometryObject obj in geo)
            {
                if (obj is Solid solid && solid.Volume > 1e-6)
                {
                    solids.Add(SolidUtils.CreateTransformed(solid, transform));
                }
                else if (obj is GeometryInstance gi)
                {
                    ExtractSolidsRecursive(gi.GetInstanceGeometry(), transform.Multiply(gi.Transform), solids);
                }
            }
        }

        private class RectInterval
        {
            public double StationMin { get; set; }
            public double StationMax { get; set; }
            public double ZMin { get; set; }
            public double ZMax { get; set; }
        }
    }
}